/**
* @author      Steve Fallet <steve.fallet@divtec.ch>
* @version     3.0
* @since       2016-09-23
*
* http://usejsdoc.org/
* http://www.w3schools.com/js/js_conventions.asp
*/

//http://www.jslint.com/help.html
/*jslint this:true */
/*jslint es6, browser, devel, for, single, multivar*/
/*global window, document, alert, performance */
"use strict";

//Variables globales
let joueurs = document.querySelector('table.equipe tbody');

/**
 * Supprime un joueur de l'équipe
 * @param e événement JS
 */
function supprimerJoueur(e) {
    //Si l'élément cliqué est le bouton supprimer
    if (e.target.nodeName === 'IMG' && e.target.alt.toLowerCase() === 'supprimer') {
        //Récupère la ligne du joueur et la supprime
        e.target.parentNode.parentNode.remove();
    }
}

/**
 * Retire la fonction au capitaine actuel
 */
function retirerCapitaine() {
    //Capitaine actuel
    const capitaine = document.querySelector('[src="img/capitaine.png"]');
    // Si il y a déjà un capitaine, on le supprime
    if(capitaine) {
        capitaine.remove();
    }
}

/**
 * Crée et retourne l'éléments du nouveau joueur en récupérant les valeurs passées en pramètre
 *
 * @param nom           nom du joueur
 * @param prenom        prénom du joueur
 * @param genre          genre 'F' ou 'G'
 * @param metier        code du métier : AUT, INF, ...
 * @param annee         Année scolaire 1, 2, 3 ou 4
 * @param capitaine     true si le joueur est capitaine
 *
 * @returns {Element}   Element HTML contenant toutes les infos du nouveau joueur
 */
function creerJoueur(nom, prenom, genre, metier, annee, capitaine) {

    /** Capitaine **/
    let imgCapitaine = '';

    if (capitaine) {
        imgCapitaine = '<img src="img/capitaine.png" alt="capitaine">';

        // /Retire la fonction au capitaine actuel
        retirerCapitaine();
    }

    /** Sexe **/
    let imgSexe = '<img src="img/homme.png" alt="homme">';

    if (genre === 'F') {
        imgSexe = '<img src="img/femme.png" alt="femme">';
    }

    /** Nouvelle ligne de tableau **/
    //Contenu de la ligne
    joueurs.innerHTML += `
     <tr>
        <td>${imgCapitaine}</td>
        <td>${imgSexe}</td>
        <td>${prenom}</td>
        <td>${nom.toUpperCase()}</td>
        <td>${metier} ${annee}</td>
        <td>
            <img src="img/supprimer.png" alt="Supprimer" title="Supprimer">
        </td>
    </tr>`;
}

/**
 * Remets les valeurs par défaut au formulaire
 */
function resetForm() {
    document.getElementById('nom').value = '';
    document.getElementById('prenom').value = '';
    document.getElementById('genre_f').checked = false;
    document.getElementById('genre_g').checked = false;
    document.getElementById('metier').selectedIndex = 0;
    document.getElementById('annee').value = '';
    document.getElementById('capitaine').checked = false;
}

/**
 * Fonction qui ajoute un invité à la liste des invités
 * @param e Event Object
 */
function ajouterJoueur(e) {
    //Désactive l'envoi du formulaire
    e.preventDefault();

    /** Test nom et préenom **/
    let nom = document.getElementById('nom').value.trim();
    let prenom = document.getElementById('prenom').value.trim();

    if (!nom || !prenom) {
        alert("Entrez un nom et un prénom pour le joueur !");
        return;
    }
    console.log('genre: ', document.querySelector('[name="genre"]:checked'));
    /** Test si genre sélectionné **/
    if (!document.querySelector('[name="genre"]:checked')) {
        alert("Sélectionnez le genre du joueur !");
        return;
    }

    let genre = document.querySelector('[name="genre"]:checked').value.toUpperCase();

    /** Test métier et année **/
    let metier = document.getElementById('metier').value;
    let annee = parseInt(document.getElementById('annee').value);

    if (!metier || isNaN(annee) || annee > 4 || annee < 1) {
        alert("Sélectionnez un métier et une année scolaire valide !");
        return;
    }

    /** Capitaine **/
    let capitaine = document.getElementById('capitaine').checked;


    /** Création du joueur **/
    creerJoueur(nom, prenom, genre, metier, annee, capitaine);

    resetForm();

}

/** Gestion des événments de la page **/
//Envoi du formulaire
document.querySelector('form').addEventListener('submit', ajouterJoueur);

//Clic sur le tableau
joueurs.addEventListener('click', supprimerJoueur);
